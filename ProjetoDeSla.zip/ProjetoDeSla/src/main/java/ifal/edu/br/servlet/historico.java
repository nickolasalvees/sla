package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import ifal.edu.br.conexao.conexaoBD;

/**
 * Servlet implementation class historico
 */
@WebServlet("/historico")
public class historico extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
		
		 int idSLA = Integer.parseInt(request.getParameter("id_sla"));
	        String periodo = request.getParameter("periodo");
	        int totalAplicacoes = Integer.parseInt(request.getParameter("total_aplicacoes"));
	        BigDecimal desempenho =new BigDecimal( request.getParameter("desempenho"));

	        String sql = "INSERT INTO Historico_SLA (id_sla, periodo, total_aplicacoes, desempenho) VALUES (?, ?, ?, ?)";

	        try (Connection conn = conexaoBD.getConexao();
	             PreparedStatement ps = conn.prepareStatement(sql)) {

	            ps.setInt(1, idSLA);
	            ps.setString(2, periodo);
	            ps.setInt(3, totalAplicacoes);
	            ps.setBigDecimal	(4, desempenho);
	            ps.executeUpdate();

	            response.sendRedirect("paginainicial.html");

	        } catch (SQLException | ClassNotFoundException e) {
	            throw new ServletException(e);
	        }
	    
	}

}
