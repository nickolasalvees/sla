package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import ifal.edu.br.conexao.conexaoBD;


@WebServlet("/sla")
public class sla extends HttpServlet {
	private static final long serialVersionUID = 1L;
       


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		  String nome = request.getParameter("nome");
	        String prioridade = request.getParameter("prioridade");
	        String criticidade = request.getParameter("criticidade");
	        
	        int tempoResp = Integer.parseInt(request.getParameter("tempo_resposta"));
	        int tempoRes = Integer.parseInt(request.getParameter("tempo_resolucao"));
	        

	        String sql = "INSERT INTO SLA (nome, tempo_resposta, tempo_resolucao, prioridade, criticidade) VALUES (?, ?, ?, ?, ?)";

	        try (Connection conn = conexaoBD.getConexao();
	             PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setString(1, nome);
	            ps.setInt(2, tempoResp);
	            ps.setInt(3, tempoRes);
	            ps.setString(4, prioridade);
	            ps.setString(5, criticidade);
	            ps.executeUpdate();
	          
	              response.sendRedirect("paginainicial.html");
	        } catch (SQLException | ClassNotFoundException e) {
	            throw new ServletException(e);
	        }
	    }
		
		
		
		
	}


