package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import ifal.edu.br.conexao.conexaoBD;

/**
 * Servlet implementation class violacao
 */
@WebServlet("/violacao")
public class violacao extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int idAtendimento = Integer.parseInt(request.getParameter("id_atendimento"));
        String data = request.getParameter("data_violacao");
        String justificativa = request.getParameter("justificativa");
        String acao = request.getParameter("acao_corretiva");

        String sql = "INSERT INTO Violacao_SLA (id_atendimento, data_violacao, justificativa, acao_corretiva) VALUES (?, ?, ?, ?)";
        try (Connection conn = conexaoBD.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idAtendimento);
            ps.setString(2, data);
            ps.setString(3, justificativa);
            ps.setString(4, acao);
            ps.executeUpdate();
            response.sendRedirect("paginainicial.html");
        } catch (SQLException | ClassNotFoundException e) {
            throw new ServletException(e);
        }
    }
	

}
