package ifal.edu.br.model;

public class tipo_Servico {
     
	private int id_sla;
	private String nome;
	     	
	public int getId_sla() {
		return id_sla;
	}
	public void setId_sla(int id_sla) {
		this.id_sla = id_sla;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
}
