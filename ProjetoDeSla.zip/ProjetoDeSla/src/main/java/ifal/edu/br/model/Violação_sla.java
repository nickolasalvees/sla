package ifal.edu.br.model;

public class Violação_sla {
	private int id_violacao;
	private atendimento atendimento;
	private String data_violação;
	private String justificativa;
	private String acao_corretiva;

	public int getId_violacao() {
		return id_violacao;
	}

	public void setId_violacao(int id_violacao) {
		this.id_violacao = id_violacao;
	}

	public atendimento getAtendimento() {
		return atendimento;
	}

	public void setAtendimento(atendimento atendimento) {
		this.atendimento = atendimento;
	}

	public String getData_violação() {
		return data_violação;
	}

	public void setData_violação(String data_violação) {
		this.data_violação = data_violação;
	}

	public String getJustificativa() {
		return justificativa;
	}

	public void setJustificativa(String justificativa) {
		this.justificativa = justificativa;
	}

	public String getAcao_corretiva() {
		return acao_corretiva;
	}

	public void setAcao_corretiva(String acao_corretiva) {
		this.acao_corretiva = acao_corretiva;
	}
}
