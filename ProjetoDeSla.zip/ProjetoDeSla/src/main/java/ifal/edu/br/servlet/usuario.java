package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import ifal.edu.br.conexao.conexaoBD;

/**
 * Servlet implementation class usuario
 */
@WebServlet("/usuario")
public class usuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
		
		String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");
 

        String sql = "INSERT INTO Usuario (nome, senha, email) VALUES (?, ?, ?)";
        
        
        
        try (Connection conn = conexaoBD.getConexao();
                PreparedStatement ps = conn.prepareStatement(sql)) {

               ps.setString(1, nome);
               ps.setString(2, email);
               ps.setString(3, senha);
              

               ps.executeUpdate();

          response.sendRedirect("paginainicial.html");          
		} catch (SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
		}
       
	}

}
