package ifal.edu.br.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexaoBD {

	public static Connection getConexao() throws SQLException, ClassNotFoundException {
		 Class.forName("org.h2.Driver");
		String url ="jdbc:h2:file:C:/Users/Aluno.DESKTOP-UVDAKLG/OneDrive/Documentos/ProjetoDeSLA/h2-2025-09-22/h2/bin/meubd";
		String usuario ="sa";
		String senha ="";


		return DriverManager.getConnection(url, usuario, senha);
     
	} 
	public static void main(String[] args) {
        try (Connection conn = getConexao()) {
            if (conn != null) {
                System.out.println("✅ Conexão estabelecida com sucesso!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Erro ao conectar: " + e.getMessage());
        }
    }

}
