package ifal.edu.br.model;

public class atendimento {
	private int id_atendimento;
	private String decricao;
	private String data_abertura;
	private String data_fechamento;
	private tipo_Servico tipoServico;
	private Usuario usuario;

	public int getId_atendimento() {
		return id_atendimento;
	}

	public void setId_atendimento(int id_atendimento) {
		this.id_atendimento = id_atendimento;
	}

	public String getDecricao() {
		return decricao;
	}

	public void setDecricao(String decricao) {
		this.decricao = decricao;
	}

	public String getData_abertura() {
		return data_abertura;
	}

	public void setData_abertura(String data_abertura) {
		this.data_abertura = data_abertura;
	}

	public String getData_fechamento() {
		return data_fechamento;
	}

	public void setData_fechamento(String data_fechamento) {
		this.data_fechamento = data_fechamento;
	}

	public tipo_Servico getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(tipo_Servico tipoServico) {
		this.tipoServico = tipoServico;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

}
