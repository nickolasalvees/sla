package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;

import ifal.edu.br.conexao.conexaoBD;


@WebServlet("/atendimento")
public class atendimento extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 String descricao = request.getParameter("descricao");
	        int idSla = Integer.parseInt(request.getParameter("id_sla"));
	        int idTipo = Integer.parseInt(request.getParameter("id_tipo"));
	        int idUsuario = Integer.parseInt(request.getParameter("id_usuario"));
		
		Timestamp dataabertura=new Timestamp(System.currentTimeMillis());
		
		String sql="INSERT INTO Atendimento (descricao, data_abertura,data_fechamento, id_sla, id_tipo, id_usuario) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

		
		try(Connection conn=conexaoBD.getConexao()	;
			PreparedStatement stmt=conn.prepareStatement(sql)){
			
		stmt.setString(1,descricao );
		stmt.setTimestamp(2,dataabertura );
		stmt.setTimestamp(3,dataabertura );
		 stmt.setInt(4, idSla);
         stmt.setInt(5, idTipo);
         stmt.setInt(6, idUsuario);
         
         stmt.executeUpdate();
         
         response.getWriter().println("<h2>✅ Atendimento cadastrado com sucesso!</h2>");
         
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
