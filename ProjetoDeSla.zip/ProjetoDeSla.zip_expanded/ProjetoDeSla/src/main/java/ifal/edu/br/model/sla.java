package ifal.edu.br.model;

public class sla {

	private int id_sla;
	private String nome;
	private String tempo_resposta;
	private String tempo_resolução;
	private String prioridade;
	private String criticidade;

	public int getId_sla() {
		return id_sla;
	}

	public void setId_sla(int id_sla) {
		this.id_sla = id_sla;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTempo_resposta() {
		return tempo_resposta;
	}

	public void setTempo_resposta(String tempo_resposta) {
		this.tempo_resposta = tempo_resposta;
	}

	public String getTempo_resolução() {
		return tempo_resolução;
	}

	public void setTempo_resolução(String tempo_resolução) {
		this.tempo_resolução = tempo_resolução;
	}

	public String getPrioridade() {
		return prioridade;
	}

	public void setPrioridade(String prioridade) {
		this.prioridade = prioridade;
	}

	public String getCriticidade() {
		return criticidade;
	}

	public void setCriticidade(String criticidade) {
		this.criticidade = criticidade;
	}

}
