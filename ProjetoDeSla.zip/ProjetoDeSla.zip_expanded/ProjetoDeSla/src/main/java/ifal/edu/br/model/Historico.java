package ifal.edu.br.model;

public class Historico {
	private int id_historico;
	private sla sla;
	private String periodo;
	private String total_aplicacao;
	private String desempenho;

	public int getId_historico() {
		return id_historico;
	}

	public void setId_historico(int id_historico) {
		this.id_historico = id_historico;
	}

	public sla getSla() {
		return sla;
	}

	public void setSla(sla sla) {
		this.sla = sla;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public String getTotal_aplicacao() {
		return total_aplicacao;
	}

	public void setTotal_aplicacao(String total_aplicacao) {
		this.total_aplicacao = total_aplicacao;
	}

	public String getDesempenho() {
		return desempenho;
	}

	public void setDesempenho(String desempenho) {
		this.desempenho = desempenho;
	}

}
