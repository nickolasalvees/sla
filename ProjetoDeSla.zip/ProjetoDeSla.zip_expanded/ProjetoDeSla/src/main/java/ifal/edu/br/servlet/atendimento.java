package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.sql.Timestamp;
import org.json.JSONArray;
import org.json.JSONObject;
import ifal.edu.br.conexao.conexaoBD;

@WebServlet("/atendimento")
public class atendimento extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // CREATE (POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));

        String descricao = json.getString("descricao");
        int idSla = json.getInt("id_sla");
        int idTipo = json.getInt("id_tipo");
        int idUsuario = json.getInt("id_usuario");
        Timestamp dataAbertura = new Timestamp(System.currentTimeMillis());

        String sql = "INSERT INTO Atendimento (descricao, data_abertura, data_fechamento, id_sla, id_tipo, id_usuario) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = conexaoBD.getConexao(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, descricao);
            stmt.setTimestamp(2, dataAbertura);
            stmt.setTimestamp(3, dataAbertura);
            stmt.setInt(4, idSla);
            stmt.setInt(5, idTipo);
            stmt.setInt(6, idUsuario);
            stmt.executeUpdate();

            response.setStatus(HttpServletResponse.SC_CREATED);
            response.getWriter().write("{\"message\":\"Atendimento cadastrado com sucesso\"}");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(500, e.getMessage());
        }
    }

    // READ (GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        String id = request.getParameter("id");

        String sql = (id == null) ? "SELECT * FROM Atendimento" : "SELECT * FROM Atendimento WHERE id_atendimento=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            if (id != null) ps.setInt(1, Integer.parseInt(id));

            ResultSet rs = ps.executeQuery();
            JSONArray array = new JSONArray();

            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("id_atendimento", rs.getInt("id_atendimento"));
                obj.put("descricao", rs.getString("descricao"));
                obj.put("data_abertura", rs.getTimestamp("data_abertura"));
                obj.put("data_fechamento", rs.getTimestamp("data_fechamento"));
                obj.put("id_sla", rs.getInt("id_sla"));
                obj.put("id_tipo", rs.getInt("id_tipo"));
                obj.put("id_usuario", rs.getInt("id_usuario"));
                array.put(obj);
            }

            response.getWriter().write(array.toString());
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // UPDATE (PUT)
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));

        int id = json.getInt("id_atendimento");
        String descricao = json.getString("descricao");
        int idSla = json.getInt("id_sla");
        int idTipo = json.getInt("id_tipo");
        int idUsuario = json.getInt("id_usuario");

        String sql = "UPDATE Atendimento SET descricao=?, id_sla=?, id_tipo=?, id_usuario=? WHERE id_atendimento=?";

        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, descricao);
            ps.setInt(2, idSla);
            ps.setInt(3, idTipo);
            ps.setInt(4, idUsuario);
            ps.setInt(5, id);

            int rows = ps.executeUpdate();
            if (rows > 0)
                response.getWriter().write("{\"message\":\"Atendimento atualizado com sucesso\"}");
            else
                response.sendError(404, "Atendimento não encontrado");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // DELETE (DELETE)
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id_atendimento"));
        String sql = "DELETE FROM Atendimento WHERE id_atendimento=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            if (rows > 0)
                response.getWriter().write("{\"message\":\"Atendimento removido com sucesso\"}");
            else
                response.sendError(404, "Atendimento não encontrado");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }
}

