package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONObject;
import ifal.edu.br.conexao.conexaoBD;

@WebServlet("/sla")
public class sla extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // CREATE (POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));

        String nome = json.getString("nome");
        String prioridade = json.getString("prioridade");
        String criticidade = json.getString("criticidade");
        int tempoResp = json.getInt("tempo_resposta");
        int tempoRes = json.getInt("tempo_resolucao");

        String sql = "INSERT INTO SLA (nome, tempo_resposta, tempo_resolucao, prioridade, criticidade) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nome);
            ps.setInt(2, tempoResp);
            ps.setInt(3, tempoRes);
            ps.setString(4, prioridade);
            ps.setString(5, criticidade);
            ps.executeUpdate();
            response.setStatus(HttpServletResponse.SC_CREATED);
            response.getWriter().write("{\"message\":\"SLA criado com sucesso\"}");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(500, e.getMessage());
        }
    }

    // READ (GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        String id = request.getParameter("id");

        String sql = (id == null) ? "SELECT * FROM SLA" : "SELECT * FROM SLA WHERE id_sla=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            if (id != null) ps.setInt(1, Integer.parseInt(id));

            ResultSet rs = ps.executeQuery();
            JSONArray array = new JSONArray();

            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("id_sla", rs.getInt("id_sla"));
                obj.put("nome", rs.getString("nome"));
                obj.put("tempo_resposta", rs.getInt("tempo_resposta"));
                obj.put("tempo_resolucao", rs.getInt("tempo_resolucao"));
                obj.put("prioridade", rs.getString("prioridade"));
                obj.put("criticidade", rs.getString("criticidade"));
                array.put(obj);
            }

            response.getWriter().write(array.toString());
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // UPDATE (PUT)
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));
        int id = json.getInt("id_sla");

        String sql = "UPDATE SLA SET nome=?, tempo_resposta=?, tempo_resolucao=?, prioridade=?, criticidade=? WHERE id_sla=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, json.getString("nome"));
            ps.setInt(2, json.getInt("tempo_resposta"));
            ps.setInt(3, json.getInt("tempo_resolucao"));
            ps.setString(4, json.getString("prioridade"));
            ps.setString(5, json.getString("criticidade"));
            ps.setInt(6, id);

            int rows = ps.executeUpdate();
            if (rows > 0)
                response.getWriter().write("{\"message\":\"SLA atualizado com sucesso\"}");
            else
                response.sendError(404, "SLA não encontrado");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // DELETE (DELETE)
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id_sla"));
        String sql = "DELETE FROM SLA WHERE id_sla=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();

            if (rows > 0)
                response.getWriter().write("{\"message\":\"SLA removido com sucesso\"}");
            else
                response.sendError(404, "SLA não encontrado");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }
}


