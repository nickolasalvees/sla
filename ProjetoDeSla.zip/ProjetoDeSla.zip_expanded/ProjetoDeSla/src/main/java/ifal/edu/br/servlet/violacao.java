package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONObject;
import ifal.edu.br.conexao.conexaoBD;

@WebServlet("/violacao")
public class violacao extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // CREATE (POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));

        int idAtendimento = json.getInt("id_atendimento");
        String data = json.getString("data_violacao");
        String justificativa = json.getString("justificativa");
        String acao = json.getString("acao_corretiva");

        String sql = "INSERT INTO Violacao_SLA (id_atendimento, data_violacao, justificativa, acao_corretiva) VALUES (?, ?, ?, ?)";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idAtendimento);
            ps.setString(2, data);
            ps.setString(3, justificativa);
            ps.setString(4, acao);
            ps.executeUpdate();

            response.setStatus(HttpServletResponse.SC_CREATED);
            response.getWriter().write("{\"message\":\"Violação cadastrada com sucesso\"}");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // READ (GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        String id = request.getParameter("id");

        String sql = (id == null) ? "SELECT * FROM Violacao_SLA" : "SELECT * FROM Violacao_SLA WHERE id_violacao=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            if (id != null) ps.setInt(1, Integer.parseInt(id));

            ResultSet rs = ps.executeQuery();
            JSONArray array = new JSONArray();

            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("id_violacao", rs.getInt("id_violacao"));
                obj.put("id_atendimento", rs.getInt("id_atendimento"));
                obj.put("data_violacao", rs.getString("data_violacao"));
                obj.put("justificativa", rs.getString("justificativa"));
                obj.put("acao_corretiva", rs.getString("acao_corretiva"));
                array.put(obj);
            }

            response.getWriter().write(array.toString());
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // UPDATE (PUT)
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));
        int id = json.getInt("id_violacao");

        String sql = "UPDATE Violacao_SLA SET id_atendimento=?, data_violacao=?, justificativa=?, acao_corretiva=? WHERE id_violacao=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, json.getInt("id_atendimento"));
            ps.setString(2, json.getString("data_violacao"));
            ps.setString(3, json.getString("justificativa"));
            ps.setString(4, json.getString("acao_corretiva"));
            ps.setInt(5, id);

            int rows = ps.executeUpdate();
            if (rows > 0)
                response.getWriter().write("{\"message\":\"Violação atualizada com sucesso\"}");
            else
                response.sendError(404, "Violação não encontrada");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // DELETE (DELETE)
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id_violacao"));
        String sql = "DELETE FROM Violacao_SLA WHERE id_violacao=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            if (rows > 0)
                response.getWriter().write("{\"message\":\"Violação removida com sucesso\"}");
            else
                response.sendError(404, "Violação não encontrada");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }
}

