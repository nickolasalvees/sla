package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.math.BigDecimal;
import org.json.JSONArray;
import org.json.JSONObject;
import ifal.edu.br.conexao.conexaoBD;

@WebServlet("/historico")
public class historico extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // CREATE (POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));

        int idSla = json.getInt("id_sla");
        String periodo = json.getString("periodo");
        int totalAplicacoes = json.getInt("total_aplicacoes");
        BigDecimal desempenho = json.getBigDecimal("desempenho");

        String sql = "INSERT INTO Historico_SLA (id_sla, periodo, total_aplicacoes, desempenho) VALUES (?, ?, ?, ?)";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idSla);
            ps.setString(2, periodo);
            ps.setInt(3, totalAplicacoes);
            ps.setBigDecimal(4, desempenho);
            ps.executeUpdate();
            response.setStatus(HttpServletResponse.SC_CREATED);
            response.getWriter().write("{\"message\":\"Histórico cadastrado com sucesso\"}");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // READ (GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        String id = request.getParameter("id");

        String sql = (id == null) ? "SELECT * FROM Historico_SLA" : "SELECT * FROM Historico_SLA WHERE id_historico=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            if (id != null) ps.setInt(1, Integer.parseInt(id));

            ResultSet rs = ps.executeQuery();
            JSONArray array = new JSONArray();

            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("id_historico", rs.getInt("id_historico"));
                obj.put("id_sla", rs.getInt("id_sla"));
                obj.put("periodo", rs.getString("periodo"));
                obj.put("total_aplicacoes", rs.getInt("total_aplicacoes"));
                obj.put("desempenho", rs.getBigDecimal("desempenho"));
                array.put(obj);
            }

            response.getWriter().write(array.toString());
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // UPDATE (PUT)
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));
        int id = json.getInt("id_historico");

        String sql = "UPDATE Historico_SLA SET id_sla=?, periodo=?, total_aplicacoes=?, desempenho=? WHERE id_historico=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, json.getInt("id_sla"));
            ps.setString(2, json.getString("periodo"));
            ps.setInt(3, json.getInt("total_aplicacoes"));
            ps.setBigDecimal(4, json.getBigDecimal("desempenho"));
            ps.setInt(5, id);

            int rows = ps.executeUpdate();
            if (rows > 0)
                response.getWriter().write("{\"message\":\"Histórico atualizado com sucesso\"}");
            else
                response.sendError(404, "Histórico não encontrado");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // DELETE (DELETE)
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id_historico"));
        String sql = "DELETE FROM Historico_SLA WHERE id_historico=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            if (rows > 0)
                response.getWriter().write("{\"message\":\"Histórico removido com sucesso\"}");
            else
                response.sendError(404, "Histórico não encontrado");
        } catch (Exception e) {

