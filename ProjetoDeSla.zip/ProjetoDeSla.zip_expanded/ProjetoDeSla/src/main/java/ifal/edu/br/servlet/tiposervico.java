package ifal.edu.br.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONObject;
import ifal.edu.br.conexao.conexaoBD;

@WebServlet("/tiposervico")
public class tiposervico extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // CREATE (POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));
        String nome = json.getString("nome");

        String sql = "INSERT INTO Tipo_Servico (nome) VALUES (?)";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nome);
            ps.executeUpdate();
            response.setStatus(HttpServletResponse.SC_CREATED);
            response.getWriter().write("{\"message\":\"Tipo de serviço cadastrado com sucesso\"}");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // READ (GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        String id = request.getParameter("id");

        String sql = (id == null) ? "SELECT * FROM Tipo_Servico" : "SELECT * FROM Tipo_Servico WHERE id_tipo=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            if (id != null) ps.setInt(1, Integer.parseInt(id));

            ResultSet rs = ps.executeQuery();
            JSONArray array = new JSONArray();

            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("id_tipo", rs.getInt("id_tipo"));
                obj.put("nome", rs.getString("nome"));
                array.put(obj);
            }

            response.getWriter().write(array.toString());
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // UPDATE (PUT)
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject json = new JSONObject(request.getReader().lines().reduce("", String::concat));
        int id = json.getInt("id_tipo");
        String nome = json.getString("nome");

        String sql = "UPDATE Tipo_Servico SET nome=? WHERE id_tipo=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nome);
            ps.setInt(2, id);
            int rows = ps.executeUpdate();

            if (rows > 0)
                response.getWriter().write("{\"message\":\"Tipo de serviço atualizado com sucesso\"}");
            else
                response.sendError(404, "Tipo de serviço não encontrado");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }

    // DELETE (DELETE)
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id_tipo"));
        String sql = "DELETE FROM Tipo_Servico WHERE id_tipo=?";
        try (Connection conn = conexaoBD.getConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();

            if (rows > 0)
                response.getWriter().write("{\"message\":\"Tipo de serviço removido com sucesso\"}");
            else
                response.sendError(404, "Tipo de serviço não encontrado");
        } catch (Exception e) {
            response.sendError(500, e.getMessage());
        }
    }
}

